import os
import subprocess
import sys

Import("env")

def after_build(source, target, env):
    # Define paths using PlatformIO environment variables
    uf2conv_path = os.path.join(env.subst("$PROJECT_DIR"), "uf2conv.py")
    hex_file = os.path.join(env.subst("$BUILD_DIR"), "firmware.hex")
    output_file = os.path.join(env.subst("$BUILD_DIR"), "firmware.uf2")
    family_id = "0xADA52840"  # Correct family ID for nRF52840

    # Convert to absolute paths for reliability
    uf2conv_path = os.path.abspath(uf2conv_path)
    hex_file = os.path.abspath(hex_file)
    output_file = os.path.abspath(output_file)

    # Check if uf2conv.py exists
    if not os.path.isfile(uf2conv_path):
        print(f"Error: {uf2conv_path} not found.")
        env.Exit(1)

    # Check if input .hex file exists
    if not os.path.isfile(hex_file):
        print(f"Error: {hex_file} not found.")
        env.Exit(1)

    # Command to convert .hex to .uf2
    cmd = [
        sys.executable,  # Use the current Python interpreter (more reliable than "py" or "python3")
        uf2conv_path,
        hex_file,
        "-c",  # Convert to UF2
        "-f", family_id,  # nRF52840 family ID
        "-o", output_file
    ]

    print(f"Converting {hex_file} to {output_file}...")
    try:
        # Run the command and capture output for debugging
        result = subprocess.run(
            cmd,
            check=True,
            text=True,
            capture_output=True
        )
        print(f"UF2 file generated at: {output_file}")
        print(f"Command output: {result.stdout}")
    except subprocess.CalledProcessError as e:
        print(f"Error during UF2 conversion: {e}")
        print(f"Command error output: {e.stderr}")
        env.Exit(1)
    except FileNotFoundError as e:
        print(f"Error: Python interpreter or {uf2conv_path} not found: {e}")
        env.Exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        env.Exit(1)

# Add the post-build action
env.AddPostAction("buildprog", after_build)